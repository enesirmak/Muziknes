![Repo Banner](https://user-images.githubusercontent.com/87353286/144381080-faf8e557-7909-43a1-a8e2-208936e5a8f8.png)



# BlackHole

Awesome Music Player made with Flutter!

[![made-with-flutter](https://img.shields.io/badge/Made%20with-Flutter-1f425f.svg)](https://flutter.dev/) ![Release](https://img.shields.io/github/v/release/Sangwan5688/BlackHole) ![Downloads](https://img.shields.io/github/downloads/Sangwan5688/BlackHole/total)
[![Build](https://github.com/Sangwan5688/BlackHole/actions/workflows/flutter.yml/badge.svg)](https://github.com/Sangwan5688/BlackHole/actions/workflows/flutter.yml)
[![Translation-Status](https://hosted.weblate.org/widgets/blackhole/-/translations/svg-badge.svg)](https://hosted.weblate.org/engage/blackhole/)

### Dont forget to :star: the repo

[![GitHub stars](https://img.shields.io/github/stars/Sangwan5688/BlackHole.svg?style=social&label=Star)](https://github.com//Sangwan5688/BlackHole) ![GitHub forks](https://img.shields.io/github/forks/Sangwan5688/BlackHole.svg?style=social&label=Forks) ![GitHub followers](https://img.shields.io/github/followers/Sangwan5688.svg?style=social&label=Follow)

## Download

[<img src="https://gitlab.com/IzzyOnDroid/repo/-/raw/master/assets/IzzyOnDroid.png"
     alt="Get it on IzzyDroid"
     height="100">](https://android.izzysoft.de/repo/apk/com.shadow.blackhole)
[<img src="https://fdroid.gitlab.io/artwork/badge/get-it-on.png"
     alt="Get it on F-Droid"
     height="100">](https://f-droid.org/packages/com.shadow.blackhole/)

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
[<img src="https://img.shields.io/badge/GitHub-181717?logo=github&logoColor=white"
     alt="Download from GitHub"
     height="60">](https://github.com/Sangwan5688/BlackHole/releases)
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
[<img src="https://img.shields.io/badge/Telegram-2CA5E0?logo=telegram&logoColor=white"
     alt="Join Telegram Channel"
     height="60">](https://t.me/blackhole_official)

## Translations

- [Spanish :es:](/README.ES.md)
- [Russian :ru:](/README.RU.md)
- [French :fr:](/README.FR.md)
- [Turkish :tr:](/README.TR.md)

[Translate App on Weblate](https://hosted.weblate.org/projects/blackhole/translations/)

## Features

* Best Streaming Quality (320kbps aac)
* Song, Album, Artist and Playlist Search
* Language Specific Promoted Playlists
* Trending Songs
* Artist and Genre Radios
* Support 15+ music languages
* Local and Global Top Spotify songs
* Add Songs to Favorite
* Playlists support
* Import Playlists from Spotify & YouTube
* Import/Export Playlists as JSON File
* Share Playlists
* Sleep timer
* Lyrics Support
* Queue Management
* Listening history record
* Dark mode / accent color
* Custom Gradients and other Theme options
* Supports Portrait as well as Landscape mode
* Download for offline play (320kbps with ID3 tags)
* Play Online as well as Offline Songs
* Tag Editing Support
* Trending Search Results
* YouTube Search Support
* Promoted Youtube Playlists
* Play videos as audio
* Auto Song Recommendations
* Inbuilt Equalizer
* Backup & Restore
* Auto Update Check
* Cache support
* No Subscription
* No Ads

and much more...
Check it yourself :)

## Screenshots
<img src="https://github.com/Sangwan5688/BlackHole/blob/main/fastlane/metadata/android/en-US/images/phoneScreenshots/1.png?raw=true" width="32%"> <img src="https://github.com/Sangwan5688/BlackHole/blob/main/fastlane/metadata/android/en-US/images/phoneScreenshots/2.png?raw=true" width="32%"> <img src="https://github.com/Sangwan5688/BlackHole/blob/main/fastlane/metadata/android/en-US/images/phoneScreenshots/3.png?raw=true" width="32%"> <img src="https://github.com/Sangwan5688/BlackHole/blob/main/fastlane/metadata/android/en-US/images/phoneScreenshots/4.png?raw=true" width="32%"> <img src="https://github.com/Sangwan5688/BlackHole/blob/main/fastlane/metadata/android/en-US/images/phoneScreenshots/5.png?raw=true" width="32%"> <img src="https://github.com/Sangwan5688/BlackHole/blob/main/fastlane/metadata/android/en-US/images/phoneScreenshots/6.png?raw=true" width="32%">

## License
```
Copyright © 2021 Enes Irmak

BlackHole is free software licensed under GPL v3.0.
You can redistribute and/or modify it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

BlackHole is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.
```
